﻿using System.Collections.Generic;
using System.Net.WebSockets;

namespace HandlerProject
{
    public static class WebSocketDictionary
    {
        public static IDictionary<string, WebSocket> Sockets = new Dictionary<string, WebSocket>();
    }
}
